# Flappy-Bird
The classic game of flappy bird made with python and pygame.
